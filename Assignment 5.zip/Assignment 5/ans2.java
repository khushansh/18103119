import java.util.*;
import java.lang.*;
public class ans2 extends Thread
{
    static int maxDiv = 0;
    static int res_num = 0;       
    int start;
    ans2(int start)
    {
        this.start = start;
    }
    public void run()
    {
        int numdiv=0;
        for(int i=start; i<this.start+10000; i++)
        {
            numdiv=0;
            for(int j=1; j<=i; j++)
            {
                if(i%j==0)
                {
                    numdiv+=1;
                }
            }
            if(numdiv>maxDiv)
            {
                synchronized(this)
                {
                    maxDiv = numdiv;
                    res_num = i;
                }
            }
        }
    }
    public static void main(String[] args)
    {
        ans2 t1 = new ans2(1);
        ans2 t2 = new ans2(10001);
        ans2 t3 = new ans2(20001);
        ans2 t4 = new ans2(30001);
        ans2 t5 = new ans2(40001);
        ans2 t6 = new ans2(50001);
        ans2 t7 = new ans2(60001);
        ans2 t8 = new ans2(70001);
        ans2 t9 = new ans2(80001);
        ans2 t10 = new ans2(90001);
        long startingTime = System.currentTimeMillis();
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();
        t8.start();
        t9.start();
        t10.start();
        try{
        t1.join();
        t2.join();
        t3.join();
        t4.join();
        t5.join();
        t6.join();
        t7.join();
        t8.join();
        t9.join();
        t10.join();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        long ending_t = System.currentTimeMillis();
        System.out.println("Number which has largest number of divisors = " + res_num + ", which has number of divisors = " + maxDiv);
        System.out.println("Total time elapsed: " + (ending_t - startingTime) + " milliseconds.");
    }
}