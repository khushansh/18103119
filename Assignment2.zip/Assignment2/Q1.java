import java.io.*;
import java.util.*;

public class lexicographically{

    public static void main(String[] args) {
    	Scanner input = new Scanner(System.in);
        System.out.print("Enter String: ");
        String s1 = input.nextLine();
        System.out.print("Enter second string:  ");
        String s2=input.nextLine();
        int l1,l2;
        l1=s1.length();
        l2=s2.length();
        int flag=0;
        for(int i=0;i<l1 && i <l2;i++){
        	if((int)s1.charAt(i) ==  (int)s2.charAt(i))
        	{
        		continue;
        	}
        	else{
        		System.out.println((int)s1.charAt(i) - (int)s2.charAt(i));
        		flag=1;
        		break;
        	}
        }
        if(flag==0){
        	if(l1!=l2){
        		System.out.println(l1-l2);
        	}
        	else{
        		System.out.println(l1-l2);
        	}
        }
    }
}
