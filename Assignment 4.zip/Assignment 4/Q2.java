public class Q2 {
	public static void main(String[] args) {
		int a = -1;
		byte b = (byte)a;
		char c = (char)b;
		int i = (int)c;
		System.out.println(i);
	}
}