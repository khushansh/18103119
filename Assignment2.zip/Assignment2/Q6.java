import java.io.*;
import java.util.*;

public class Hailstrom{

    public static void main(String[] args) {
    	Scanner input = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int t = input.nextInt();
        
        System.out.print("Hailstrom sequence: ");
        System.out.print(t+" ");
        while(t!=1){
        	if(t<0){
        	System.out.print("Enter Only positive number ");
        	break;
            }

        	else if(t==0){
        	System.out.print("Error");
        	break;
            }
        	else if(t%2==0){
        		t=t/2;
        		System.out.print(t+" ");
        	}
        	else{
        		t=3*t +1;
        		System.out.print(t+" ");
        	}
        }
        
    }
}