import java.util.*;
import java.io.*;
public class ans2{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try{
			System.out.print("Enter size of array: ");
			int n=sc.nextInt();
			sc.nextLine();
			int[] countings=new int[21];
			int[] arr=new int[n];
			for(int i=0;i<n;i++)
			{
				System.out.printf("Enter %dth integer of array from range of 0 to 20: ",i);
				int x=sc.nextInt();
				if(x<0||x>20)
				{
					System.out.print("You have entered something wrong! Value must be lie within the range of 0 to 20.");
					return ;
				}
				countings[x]++;
				arr[i]=x;
			}
			System.out.print("Given array is: ");
			for(int i=0;i<n;i++)
			{
				System.out.printf("%d ",arr[i]);
			}
			System.out.println();
			System.out.print("Sorted array is (using counting sort algorithm in increasing order): ");
			for(int i=0;i<21;i++)
			{
				for(int j=0;j<countings[i];j++)
				{
					System.out.printf("%d ",i);
				}
			}
	    }
		catch(InputMismatchException e)
		{
			System.out.println("You have entered something wrong! Value must be of suitable Datatype.");
		}
	}
}