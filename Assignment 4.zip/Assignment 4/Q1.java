import java.util.Arrays;
import java.util.Scanner;

class Q1 {
	public static void main(String[] args)
	{
		int n;
		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		in.nextLine();
		String[] crops = new String[n];
		for (int i=0;i<n;i++){
			crops[i]=in.nextLine().trim();
		}
		System.out.print(replant(crops));
	}
	
	
	public static int help(String[] crops) {
		int N = crops.length;
		int M = crops[0].length();
		int cropp[][] = new int[N][M];
		for(int i = 0;i<N;++i)
			Arrays.fill(cropp[i], 0);
		cropp[0][0] = 0;
		for(int i= 1;i<N;++i) {
			cropp[i][0] = cropp[i-1][0];
			if(crops[i].charAt(0)!=' '&&crops[i].charAt(0)==crops[i-1].charAt(0)) {
				cropp[i][0] = 1+cropp[i][0];
				String s = crops[i];
				s = ' '+s.substring(1);
				crops[i] = s;
			}
		}
		for(int i = 1;i<M;++i) {
			cropp[0][i] = cropp[0][i-1];
			if(crops[0].charAt(i)!=' '&&crops[0].charAt(i)==crops[0].charAt(i-1)) {
				cropp[0][i] = 1+cropp[0][i];
				String s = crops[0];
				s = s.substring(0,i)+' '+s.substring(i+1);
				crops[0] = s;
			}
		}
		for(int i = 1;i<N;++i) {
			for(int j = 1;j<M;++j) {
				cropp[i][j] = cropp[i-1][j]+cropp[i][j-1]-cropp[i-1][j-1];
				if((crops[i].charAt(j)==crops[i].charAt(j-1))||(crops[i].charAt(j)==crops[i-1].charAt(j))){
					cropp[i][j] = 1+cropp[i][j];	
					String abc = crops[i];
					abc = abc.substring(0,j)+' '+abc.substring(j+1);
					crops[i] = abc;
				}
			}
		}
		return cropp[N-1][M-1];
	}
	
	public static int replant(String[] crops){
		int crop_len = crops.length;
		String dup_crop[] = new String[crop_len];
		for(int i = 0;i<crop_len;++i) {
			StringBuilder t = new StringBuilder(crops[i]);
			dup_crop[i] =  t.reverse().toString();
		}
		int v1 = help(crops);
		int v2 = help(dup_crop);
		return (v1>v2)?v2:v1;	
	}
}